<template>
  <div id="app">
    <home></home>
  </div>
</template>

<script>
import Home from './views/Home'
export default {
  components: {
    Home
  }
}
</script>

<style>
html, body {
  width: 100%;
  margin: 0;
  padding: 0;
}
</style>
